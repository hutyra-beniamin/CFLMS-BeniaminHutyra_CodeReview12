<?php get_header(); ?>


<div class="container-fluid m-0 p-0">
        <div class="row m-0 p-0 col-12" style="background: url('https://images.pexels.com/photos/355241/pexels-photo-355241.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940')fixed; height: 100vh; width:100%; background-size:cover; background-repeat:no-repeat;">
            <div class="container pt-5 mt-5">
                <h1 class="display-4 text-white text-center"><?php bloginfo('name'); ?></h1>
                <p class="lead text-white text-center">Traveling is what we love the most!</p> 
                <br>
                <br>
                <br>
                <div class="container text-center mt-5 pt-5">
            <a href="http://localhost/codefactory/index.php/blog/" class="btn btn-outline-dark">Find out more</a>
            </div>
            </div>
           
        </div>
</div>
                


<?php get_footer(); ?>