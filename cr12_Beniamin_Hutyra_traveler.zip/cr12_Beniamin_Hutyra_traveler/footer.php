<?php wp_footer(); ?>
<footer>
  <br>
  <br>
    <div class="container-fluid d-flex justify-content-around p-2 fixed-bottom" id="footer">
    <!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- Add font awesome icons -->
<a href="#" class="fa fa-facebook p-2" style="font-size: 1.5rem; text-decoration:none;"></a>
<a href="#" class="fa fa-twitter p-2" style="font-size: 1.5rem; text-decoration:none;"></a>
<a href="#" class="fa fa-instagram p-2" style="font-size: 1.5rem; text-decoration:none;"></a>
<a href="#" class="fa fa-pinterest p-2" style="font-size: 1.5rem; text-decoration:none;"></a>
    </div>
</footer>

</body>

</html>